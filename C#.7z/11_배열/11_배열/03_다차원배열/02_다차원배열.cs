﻿using System;

// > 2차원 배열을 3개를 만든 뒤
//   PrintArr() 로 출력해주세요.

class _02_다차원배열
{
	private void PrintArr(int[,] value)
	{
		int len2 = value.GetLength(0);
		int len1 = value.GetLength(1);

		for(int i = 0;i < len2; i++)
		{
			for (int j = 0; j < len1; j++)
			{
				int elevalue = value[i, j];
				Console.Write("[ " + (elevalue < 10 ? " " : "") + elevalue + " ]");
			}
			Console.WriteLine();
		}
	}


	private static void Main() { new _02_다차원배열().Entry(); }
	private void Entry()
	{
		int[,] myArray1 = new int[5, 5];
		int len2 = myArray1.GetLength(0);
		int len1 = myArray1.GetLength(1);
		int count = 0;

		for (int i = 0; i < len2; i++)
		{
			for (int j = 0; j < len1; j++)
			{
				myArray1[i, j] = ++count;
			}
		}

		int[,] myArray2 = new int[4, 4] { {1,2,3,4}, {5,6,7,8}, {9,10,11,12},{13,14,15,16} };


		int[,] myArray3 = { { 1, 2, 3 }, { 4, 5, 6 } };


		PrintArr(myArray1);
		Console.WriteLine();
		PrintArr(myArray2);
		Console.WriteLine();
		PrintArr(myArray3);
	}
}

