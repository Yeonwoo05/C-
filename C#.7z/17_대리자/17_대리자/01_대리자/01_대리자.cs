﻿using System;

// > 대리자(Delegate)?
/// - 메서드 보다 효율적으로 사용하기 위해서 특정 메서드 자체를 캡슐화 할 수 있게
/// 만들어주는 기능입니다.

// > Delegate 선언 방법
/// - delegate 키워드를 이용해서 자신이 대리할 메서드의
/// 반환 형식을 명시해서 대리자의 이름을 작성합니다
/// - 매개변수 목록을 작성합니다.

class _01_대리자
{
	private delegate void MyDelegate(int A, int B);

	// 반환형식  : void, int형식 매서드 두개를 갖는 메서드를 대리할 수 있는 대리자
	private void Plus(int num1, int num2)
	{
		Console.WriteLine(num1 + " + " + num2 + " = " + (num1 + num2));
	}
	private void Minus (int num1, int num2)
	{
		Console.WriteLine(num1 + " - " + num2 + " = " + (num1 - num2));	
	}
	private static void Main() { new _01_대리자().Entry(); }
	private void Entry() 
	{
		// Delegate 타입의 대리자 선언
		MyDelegate CalMethod;

		Console.WriteLine("어떤 계산을 할까요 ? ");
		Console.WriteLine("덧셈 / 뺄셈");
		string calculateType = Console.ReadLine();
		switch(calculateType)
		{
			case "덧셈":
				// 대리자 인스턴스를 생성할 때 new
				// 인수로 대리할 메서드의 이름을 적어줍니다.
				CalMethod = new MyDelegate(Plus);
				break;
			default:
				CalMethod = new MyDelegate(Minus);
				break;
		}
		Console.Write("계산할 숫자1을 입력해주세요 : ");
		int num1 = int.Parse(Console.ReadLine());
		Console.Write("계산할 숫자2을 입력해주세요 : ");
		int num2 = int.Parse(Console.ReadLine());

		// 대리하는 메서드를 호출합니다.
		CalMethod?.Invoke(num1, num2);
	}
}