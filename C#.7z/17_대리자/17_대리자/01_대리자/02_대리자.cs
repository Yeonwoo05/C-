﻿using System;
using System.ComponentModel;

class _02_대리자
{
	// > 반복이 끝났을 경우 호출할 메서드를 대리할 대리자 형식
	private delegate void WhileEndEvent();

	private void PrintArray(int [] array, WhileEndEvent endEvent = null)
	{
		foreach (var i in array)
			Console.Write(i + " ");
		Console.WriteLine();

		// 대리자를 이용해서 호출
		endEvent?.Invoke();
	}
	private void PrintEnd()
	{
		Console.WriteLine("모든 반복이 끝남!");
	}
	private static void Main()
	{
		new _02_대리자().Entry();
	}
	private void Entry()
	{

		int[] myArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		PrintArray(myArray, PrintEnd);
	}
}