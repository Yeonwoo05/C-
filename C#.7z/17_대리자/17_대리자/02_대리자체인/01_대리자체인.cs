﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Delegate는 여러개의 메서드를 대리할 수 있습니다.
// 이러한 행위를 Deleagate Chain 이라고 합니다.
// '+' 를 통해서 체인을 추가할 수 있습니다.
// += 를 이용해서 추가 대리를 시킵니다.
// -= 를 이용해서 해당하는 메서드를 제외시킬수 있습니다.

namespace _17_대리자._02_대리자체인
{
	class _01_대리자체인
	{
		private void PrintA() { Console.WriteLine("A"); }
		private void PrintB() { Console.WriteLine("B"); }
		private void PrintC() { Console.WriteLine("C"); }

		private delegate void PrintDelegate();

		private static void Main() { new _01_대리자체인().Entry(); }
		private void Entry()
		{
			PrintDelegate printDel = PrintA;
			printDel += PrintB;
			printDel += PrintC;

			printDel?.Invoke();
			printDel -= PrintC;
			printDel -= PrintB;
			printDel?.Invoke();

		}

	}
}
