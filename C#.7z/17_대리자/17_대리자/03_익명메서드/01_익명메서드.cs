﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 익명 메서드란?
// - 이름이 없는 메서드를 의미합니다.
// - delegate를 이용해서 메서드를 대리하는 것이 아닌 코드 블록 대리시켜 사용합니다.
// - 대리자에 대리시키기 위해서만 사용되고, 다른 곳에서는 두번 다시 사용할 일이 없는
// 메서드의 경우 익명 메서드를 사용합니다.

namespace _17_대리자._03_익명메서드
{
	class _01_익명메서드
	{
		// 대리자 선언
		private delegate void Anonymous(string str);
		private static void Main() { new _01_익명메서드().Entry(); }
		private void Entry()
		{
			Anonymous anonymous = delegate (string myStr)
			{ Console.WriteLine(myStr); };

			anonymous?.Invoke("익명 메서드임?");
		}
	}
}
