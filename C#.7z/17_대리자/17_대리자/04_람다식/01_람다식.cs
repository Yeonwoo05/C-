﻿using System;

// 람다식 선언 방식
// (매개변수 목록) => 식

namespace _17_대리자._04_람다식
{
	class _01_람다식
	{
		private delegate void HelloWorld();

		private static void Main() { new _01_람다식().Entry(); }
		private void Entry()
		{
			HelloWorld helloWorld = () =>
		   {
			   Console.WriteLine("Hello");
			   Console.WriteLine("World");
		   };
			// () : 매개변수 목록
			// => : 입력 연산자, 매개 변수를 전달하는 일
			// { ..  } : 실행할 내용
			// 문 형식의 람다 식
			helloWorld?.Invoke();
		}
	}
}
