﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _17_대리자._04_람다식
{
	class _02_람다식
	{
		private delegate int Calculate(int A, int B);
		private static void Main() { new _02_람다식().Entry(); }
		private void Entry()
		{
			Calculate cal = (A, B) => A + B	
			// 식 형식의 람다 식

			Console.WriteLine("10 + 20 = " + cal?.Invoke(10,20));
		}
	}
}
