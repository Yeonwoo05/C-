﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01_출력
{
	class _03_출력
	{
		// 출력개행을 이용해서
		// 자신의 이름과 포부를 적어봅시다.
		// 나는 박진혁이다! 나는 오늘부터 개발을 열심히 할꺼다!
		static void Main()
		{
			Console.WriteLine("나는 박진혁이다! 나는 오늘부터 개발을 열심히 할꺼다!");
		}
	}
}
