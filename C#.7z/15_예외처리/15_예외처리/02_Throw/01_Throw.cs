﻿using System;

class _01_Throw
{
	// 예외를 던지는 메서드를 호출하는 곳에서는 발생하는 예외에 대한 처리를 해줘야 한다.
	static void GetException()
	{
		throw new Exception("예외임");
	}

	// throw를 이용해서 특정한 예외처리를 발생
	static void Main()
	{
		try
		{
			//GetException();
			throw new Exception("예외임2");
		}
		catch(Exception e)
		{
			Console.WriteLine("예외가 발생했습니다.");
			Console.WriteLine("받은 예외 메시지 : " + e.Message);
		}
	}
}