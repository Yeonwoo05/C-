﻿using System;

// 특정한 예외 클래스를 작성할 수 있습니다.
// - Exception 클래스의 자식클래스(파생클래스)로 사용해야 합니다.
public sealed class MyException : Exception
{
	public override string Message { get => "이건 내가 만든 예외"; }
}

class _01_사용자정의예외
{ 
	static void Main()
	{
		try
		{
			throw new MyException();
		}
		catch(MyException e)
		{
			Console.WriteLine(e.Message);
		}
	}
}