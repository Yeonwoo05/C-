﻿using System;

// Finally {...}
/// - finally를 통해서 예외가 발생하든 발생하지 않든
///  무조건 어떠한 구문을 실행 시킬수 있습니다.

class _02_TryCatch
{
	static void Main()
	{
		int number = 0;

		try
		{
			Console.WriteLine("좋아하는 숫자 ?");
			number = int.Parse(Console.ReadLine());
			Console.WriteLine();
		}
		catch(FormatException)
		{
			// FormatException : 입력한 문자열의 형식이 잘못되었을 경우 발생하는 예외
			Console.WriteLine("입력한 값이 잘못되었습니다.");
			Console.WriteLine();
			Console.WriteLine("개발자가 좋아하는 13으로 설정합니다.");
			number = 13;
		}
		// 예외가 발생하든 발생하지 않든 실행됩니다.
		finally
		{
			Console.WriteLine("가장 좋아하는 숫자는 " + number + "입니다.");
			Console.WriteLine();
		}
	}
}
