﻿using System;

// > 예외(Exception)
/// - 프로그래머의 실수가 아닌, 외부 시스템이나 조건들에 의해
/// 더이상 작업을 수행하지 못하는 것을 의미합니다.

// - 예외가 발생할 것 같은 코드를 try {...} 코드 블록에서 시도
// - 특정 예외가 발생했을 경우 catch(...) {...} 처리


class _01_TryCatch
{
	static void Main()
	{
		int[] myArray = new int[5];

		try
		{
			// 예외가 발생할지도 모르는 코드를 이곳에 작성합니다.
			myArray[10] = 100;
		}
		//catch(IndexOutOfRangeException e)
		//{
		//	Console.WriteLine("예외 발생!");
		//	Console.WriteLine("배열 범위를 초과하였습니다.");
		//}
		// 모든 예외에 대한 처리
		catch(Exception e)
		{
			Console.WriteLine(e.GetType().Name);
			Console.WriteLine(e.Message);
		}

	}
}
