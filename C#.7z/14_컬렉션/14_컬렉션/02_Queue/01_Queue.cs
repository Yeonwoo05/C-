﻿using System;
using System.Collections;

// > Queue?
// - 선입 선출 방식의 컬렉션입니다.
// - 선입선출 ? FIFO
// - ArrayList와 다르게 원하는 위치에 요소를 삽입할 수 없습니다.
//   요소 삽입은 요소의 맨뒤, 요소의 제거는 맨 앞에서 이루어집니다.
//  Queue에 삽입 : Enqueue
// 제거 : Dequeue

class _01_Queue
{

	static void Main()
	{
		Queue queue = new Queue();

		queue.Enqueue("Queue 입니다.");
		queue.Enqueue(0);
		queue.Enqueue(1);
		queue.Enqueue(2);
		queue.Enqueue(3);

		Console.WriteLine("queue.Count = " + queue.Count);

		// peek()은 첫번째 요소의 값을 읽어올수 있습니다.
		Console.WriteLine("queue.Peek() : " + queue.Peek());
		Console.WriteLine("queue.Peek() : " + queue.Peek());
		Console.WriteLine("queue.Peek() : " + queue.Peek());

		foreach (var elem in queue)
			Console.WriteLine(elem);
		Console.WriteLine();

		while(queue.Count != 0)
		{
			Console.WriteLine("Queue Count = " + queue.Count);
			Console.WriteLine("Dequeue() = " + queue.Dequeue());
			Console.WriteLine();
		}
	}
}