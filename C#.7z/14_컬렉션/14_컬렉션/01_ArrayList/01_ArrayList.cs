﻿using System;
using System.Collections;

// 컬렌션?
// - 같은 성격을 띄는 데이터의 모음을 담는 자료구조 의미합니다.

// > ArrayList
// - 배열과 닮은 컬렉션입니다.
// - [] 연산자를 이용해서 컬렉션의 요소에 대한 읽기, 쓰기가 가능합니다.
// - 배열과 다르게 크기 지정없이 요소의 추가, 삭제에 따라 자동으로 크기가 설정
// - 요소의 자료형이 object 이므로 모든 타입의 데이터를 담을 수 있습니다.


class _01_ArrayList
{
	static void Main()
	{
		void AllPrintArrayList(ArrayList al)
		{
			foreach (var elem in al)
				Console.WriteLine(elem);
			Console.WriteLine();
		}
		// ArrayList는 컬렉션 초기화를 이용해서 초기화가 가능합니다.
		ArrayList arrayList = new ArrayList() { 10, 20, 30 };

		arrayList.Add("string");
		arrayList.Add(123456);
		Console.WriteLine("arrayList의 길이 : " + arrayList.Count);

		AllPrintArrayList(arrayList);

		// RemoveAt(index) : index와 일치하는 인덱스 값을 가진 엘리먼트를 제거합니다.
		arrayList.RemoveAt(0);


		AllPrintArrayList(arrayList);
		// 지정된 위치에 값을 가지는 요소 추가 : insert
		arrayList.Insert(0, "딸기스무디");
		AllPrintArrayList(arrayList);
	}
}