﻿using System;
using System.Collections;

// Stack?
// - Queue와 다르게 후입 선출 방식의 컬렉션입니다.
// - 요소의 삽입과 제거는 요소의 맨 뒤에서 이루어집니다.
// - 스택에서의 삽입 ?: Push
// - 스택에서의 제거 : pop

class _01_Stack
{
	static void Main()
	{
		Stack stack = new Stack();
		stack.Push(4);
		stack.Push(3);
		stack.Push(2);
		stack.Push(1);
		stack.Push(0);

		while(stack.Count != 0)
		{
			Console.WriteLine("Pop() = " + stack.Pop());
		}

	}


}