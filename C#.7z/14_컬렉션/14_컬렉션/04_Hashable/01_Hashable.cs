﻿using System;
using System.Collections;
using System.Security.Policy;

// Hashtable ?
// [key] [value] 로 이루어진 요소를 갖는 컬렉션입니다.
// - 배열과 비슷하게 [key] 를 이용해서 [value]를 얻을 수 있습니다.
// hashing(key를 이용해서 주소를 산출시키는 알고리즘)을 이용해서
// 데이터에 접근하기 때문에 탐색속도가 굉장히 빠릅니다.

class _01_Hashable
{
	static void Main()
	{
		Hashtable hashtable = new Hashtable();
		hashtable.Add("사과", "apple");
		hashtable.Add("바나나", "banana");
		hashtable["딸기"] = "strawberry";
		hashtable["수박"] = "watermelon";

		Console.WriteLine(hashtable["사과"]);
		Console.WriteLine(hashtable["바나나"]);
		Console.WriteLine(hashtable["딸기"]);
		Console.WriteLine(hashtable["수박"]);
	}

}
