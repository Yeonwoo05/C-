﻿using System;
// > 반복기?
// - yield 키워드를 사용해서 배열이나 컬렉션 클래스에서
// 사용자 지정 반복을 수행하는 메서드, get 접근자, 연산자를 뜻합니다.

// yield?
// - 호출자(caller)에서 컬렌셕 데이터를 하나씩 리턴할 때 또는 하나 이상의
// 반환값을 지정할 때 사용하는 키워드입니다.
// [yield return] 문을 만난다면 현재 위치가 저장되고
// 다음에 반복기가 호출되면 그 위치에서 실행이 다시 시작됩니다.
// [yield break] 문을 만난다면 실행중인 반복기를 종료합니다.

// > 반복기 정의 방법?
// - IEnunmerable 인테페이스의 GetEnumerator() 메서드를 구현합니다.
// 반복기를 정의한 클래스는 foreach 문을 이용해서 순회할 수 있습니다.
// IEnumerator GetEnumerator() 메서드를 작성한다면 foreach 루핑을 할 수 있습니다.

// IEnumerable : foreach문에서 개체를 하나식 받아 단순하게 반복할 수 있도록 지원
// 멤버 ? GetEnumerator() : IEnumerator 형식의 객체를 반환합니다.
// IEnumerator : 현재 몇번재까지 읽었는지에대한 상태를 기억하고, 요소를 순회할 때
// 필요한 내용들을 지원하는 인터페이스 입니다.

using System.Collections;

public class MyCustomCollection  : IEnumerable
{
	int[] array = null;

	public MyCustomCollection(int length, params int[] value)
	{
		// array 초기화
		array = new int[length];

		// 각 엘리먼트 초기화
		for (int i = 0; i < length; i++)
		{
			array[i] = value[i];
		}
	}
	// 해당 메서드를 작성한다면 해당 클래스 형식의 인스턴스를 이용해서
	// foreach문 사용할 수 있습니다.
	IEnumerator IEnumerable.GetEnumerator()
	{
		foreach (var elem in array)
			yield return elem;
	}
}


class _01_Yield
{
	static void Main()
	{
		MyCustomCollection myCollection = new MyCustomCollection(5, 4, 3, 2, 1, 6);
		foreach (int i in myCollection)
			Console.WriteLine(i);
	}
}