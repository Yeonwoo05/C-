﻿using System;
using System.Collections;

// IEnumerator의 멤버
// - bool MoveNext() : 다음 요소로 이동시킵니다.
//						만약 다음 요소가 존재하지  않을 경우 리턴 시킵니다.
// - void Reset()    : 컬렉션 첫번째 위치(0)의 앞(-1)로 이동시킵니다.
// - object Current {get;} : 컬렉션의 현재 요소에 대한 읽기 전용 프로퍼티 입니다.

public class MyCollection : IEnumerable, IEnumerator
{
	private int[] array;

	// 현재 컬렌셕 위치를 저장할 변수
	private int position = -1;

	public MyCollection(int length, params int[] elemValue)
	{
		array = new int[length];

		for (int i = 0; i < length; i++)
			array[i] = elemValue[i];
	}
	// 인덱서 정의
	public int this[int index]
	{
		get => array[index];
		set
		{
			// 만약 범위를 초과한 인덱스 번호를 받게된다면?
			if(index >= array.Length)
			{
				// 사이즈를 늘립니다.
				Array.Resize(ref array, index + 1);
			}

			array[index] = value;
		}
	}
	object IEnumerator.Current
	{ get => array[position]; }

	// 위치를 첫번재 요소의 앞으로 이동시킵니다.
	void IEnumerator.Reset()
	{ position = -1; }

	IEnumerator IEnumerable.GetEnumerator()
	{
		foreach (var i in array)
			yield return array[i];
	}
	bool IEnumerator.MoveNext()
	{
		// 현재 위치가 마지막 위치
		if (position == array.Length - 1)
		{
			// 초기 위치로 돌립니다.
			(this as IEnumerator).Reset();
			return false;
		}
		++position;
		return (position < array.Length);
	}
}


class _02_Yield
{
	static void Main()
	{
		MyCollection collection = new MyCollection(5, 1, 2, 3, 4, 5);

		// 반복자 선언
		IEnumerator enumerator1 = (collection as IEnumerable).GetEnumerator();
		//IEnumerator enumerator2 = (collection as IEnumerable).GetEnumerator();

		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		enumerator1.MoveNext();
		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		Console.WriteLine();
		enumerator1.MoveNext();
		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		Console.WriteLine();
		enumerator1.MoveNext();
		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		Console.WriteLine();
		enumerator1.MoveNext();
		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		Console.WriteLine();
		enumerator1.MoveNext();
		Console.WriteLine("enumerator1.Current = " + enumerator1.Current);
		Console.WriteLine();
	}
}