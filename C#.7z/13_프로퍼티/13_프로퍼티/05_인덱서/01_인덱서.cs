﻿using System;

// 인덱서란?
// - 인덱스(index)를 잉용해서 객체 내 의 데이터에 접근하게 해주는 프로퍼티 입니다.
// - 사용한다면 객체를 배열처럼 사용할 수 있습니다.
// - 인덱서는 주로 내부 배열 또는 컬렉션을 캡슐화하기 위한 형식에서 가장 많이 구현됩니다.

public class IndexerSample
{
	// > 인덱서를 통해 접근 가능하도록 할 배열을 선언합니다.
	public int[] myArray;

	// > 생성자에서 배열의 크기를 지정합니다.
	public IndexerSample(int length)
	{
		myArray = new int[length];
	}
	// > IndexerSample 형식의 객체[index]로 사용 가능하도록 정의합니다.
	/// - 한정자 인덱서 형식 this[형식 식별자] {get.. set..};
	public int this [int index]
	{
		// get 에서는 index를 이용한 클래스 내부 데이터에 접근하는 코드 작성
		get => myArray[index];
		// myArray에 접근하겠다.

		// set에서는 index를 이용한 클래스 내부 데이터에
		// 어떤 데이터를 저장하는 코드를 작성
		set
		{
			// 만약 전달될 index 값이 myArray 범위를 벗어난다면
			if (index > myArray.Length - 1)
			{
				Console.WriteLine("범위가 초과하였습니다.");
			}
			else myArray[index] = value;
		}
	}
	public int length { get => myArray.Length; }
}

class _01_인덱서
{
	private static void Main()
	{
		IndexerSample sample = new IndexerSample(10);
		for (int i = 0; i < sample.length; i++)
		{
			sample[i] = 10 + (i * 10);
			Console.WriteLine($"sample[{i}] = {sample[i]}");
		}
		sample[1000] = 50;

		//foreach (var item in sample)
		//{
		//	Console.WriteLine(item);
		//}
	}
}