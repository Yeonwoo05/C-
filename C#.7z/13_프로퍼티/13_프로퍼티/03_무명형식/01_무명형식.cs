﻿using System;

// 무명혁식
// -  이름 없는 형식을 의미합니다.
// - 임시 변수가 필요한 경우 사용됩니다.
// - 임시 변수 ? 임시로 생성해서 사용후 재사용되지 않는 변수


class _01_무명형식
{
	static void Main()
	{
		// 무형 형식 선언 방법
		/// - new { 프로퍼티 명= 값, 프로퍼티명 = 값};
		var instance = new { name = "강아지", age = 3 };
		// 읽기 전용이라서 값을 변경할 수 없습니다.
		Console.WriteLine(instance.name);
		Console.WriteLine(instance.age);
	}
}