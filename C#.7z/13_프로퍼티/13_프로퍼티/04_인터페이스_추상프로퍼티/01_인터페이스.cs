﻿using System;

// 인터페이스에 프로퍼티를 작성할 수 있습니다.
// 인터페이스에 작성한 프로퍼티는 인터페이스 내부에서 구현할 수 없습니다.
// 파생 클래스에서 무조건 구현해야 합니다.
public interface IMyInterface
{
    string hello { get; set; }
    string world { get; }
}
public class MyClass : IMyInterface
{
    string IMyInterface.hello { get; set; }
    public string world { get; private set; }
}

class _01_인터페이스
{
    private static void Main() { new _01_인터페이스().Entry(); }
    private void Entry()
    {
        MyClass myClass = new MyClass();
        Console.WriteLine(myClass.world);
        
    }
}

