﻿using System;

// 추상 프로퍼티란?
// - 구현되지 않은 프로퍼티를 의밓바니다.
// - abstract로 선언하며, 파생 클래스에서는 override로 구현합니다.

public abstract class MyAbstractClass
{
	// 추상 프로퍼티 선언
	public abstract int myProperty { get; set; }
}
public class MyClass : MyAbstractClass
{
	public override int myProperty { get; set; }
}
class _02_추상프로퍼티
{
	private static void Main()
	{
		MyAbstractClass myClass = new MyClass() { myProperty = 10 };
		Console.WriteLine("myClass.myProperty = " + myClass.myProperty);
	}
}
