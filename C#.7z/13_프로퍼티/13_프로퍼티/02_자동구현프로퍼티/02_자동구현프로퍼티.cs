﻿using System;

public class BirthDayInfo
{
	public string name { get; set; } = "UnKnown";
	public DateTime birthday { get; set; }
	public int age
	{ get => (new DateTime(DateTime.Now.Subtract(birthday).Ticks).Year); }
	// -DateTime.Now : 현재 시간
	// -DateTime.Subtract(value) : 시간을 value의 값만큼 뺍니다.
}

// 이름
// 생일 입력하고(생년월일)
// 나의 정보를 출력을 하면 됩니다.
class _02_자동구현프로퍼티
{
	private BirthDayInfo birth = null;

	private static void Main() { new _02_자동구현프로퍼티().Entry(); }

	private void Entry()
	{
		Console.Write("당신의 이름은 : ");
		string name = Console.ReadLine();
		Console.Clear();

		Console.WriteLine("당신의 생일을 입력해주세요.");
		Console.Write("年(Year) : ");
		int year = int.Parse(Console.ReadLine());
		Console.Clear();

		Console.Write("月(Month) : ");
		int month = int.Parse(Console.ReadLine());
		Console.Clear();

		Console.Write("日(Day) : ");
		int day = int.Parse(Console.ReadLine());
		Console.Clear();

		birth = new BirthDayInfo()
		{
			name = name,
			birthday = new DateTime(year, month, day)
		};
		Console.WriteLine(birth.name + "의 정보를 출력합니다.");
		Console.WriteLine("현재 나이 : " + birth.age);
		Console.WriteLine("생년월일 : " +
			birth.birthday.Year + "年 / " +
			birth.birthday.Month + "月 / " +
			birth.birthday.Day + "日");
	}
}