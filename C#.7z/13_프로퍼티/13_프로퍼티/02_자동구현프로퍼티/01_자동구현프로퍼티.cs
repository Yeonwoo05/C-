﻿using System;

// > 자동구현 프로퍼티란?
/// - C# 3.0 부터 지원하는 기능으로
/// 프로퍼티를 조금 더 간결하게 사용할 수 있습니다.
 
// 사용방법?
/// - private 변수를 선언하지 않고 프로퍼티만 구성하며
/// get; set;을 작성해서 사용합니다.

public struct Point
{
    public int x;
    public int y;
    public Point(int x, int y)
    { this.x = x;
      this.y = y;
    }
}

public class Object
{
    // 자동 구현 프로퍼티 구성
    public string objectName { get; private set; }
    // 자동 구현 프로퍼티에서도 접근 제한자를 사용해서
    // 외부에서 읽기 전용, 쓰기 전용 프로퍼티로 만들 수 있다.,
    public Point point { get; set; } = new Point(100, 100);
    // C# 7.0 자동 구현 프로퍼티를 선언함과 동시에
    // 초기화를 진행할 수 있습니다.

    public Object (string objName)
    { objectName = objName; }
    // 모든 형식은 object를 상속받기 때문에
    // ToString 형식을 오버라이딩 시킬 수 있다.
    public override string ToString()
    {
        return (objectName + " : " + point.x + ", " + point.y);
    }
}

class _01_자동구현프로퍼티
{
    private static void Main() { new _01_자동구현프로퍼티().Entry(); }
    private void Entry()
    {
        Object myObject = new Object("나의 오브젝트");

        myObject.point = new Point(300, 200);

        //myObject.point.x = 100;

        Console.WriteLine(myObject);
    }
}