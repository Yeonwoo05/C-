﻿using System;

// > 논리형식
// - 논리 형식은 bool 형식으로 사용할 수 있습니다.
// - bool 형식은 True / False로 나뉘어져 있습니다.
// - 참 -> True , 거짓 -> False를 사용합니다.


namespace _02_변수._01_기본데이터
{
	class _05_기본데이터
	{
		static void Main()
		{
			bool check1 = true;
			bool check2 = false;

			Console.WriteLine("check1 = " + check1);
			Console.WriteLine("check2 = " + check2);
		}
	}
}
